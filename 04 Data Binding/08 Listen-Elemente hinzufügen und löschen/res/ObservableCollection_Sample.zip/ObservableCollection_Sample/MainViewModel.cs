﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBinding_Liste_Sample
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private Firma firma = null;  

        public Firma Firma
        {
            get { return firma;  }
            private set { firma = value; OnPropertyChanged("Firma"); }
        }

        private Person newPerson = new Person();

        public Person NewPerson {
            get { return newPerson;  }
            set { newPerson = value; OnPropertyChanged("NewPerson"); }
        }

        private Person activePerson;
        public Person ActivePerson
        {
            get { return activePerson; }
            set { activePerson = value; OnPropertyChanged("ActivePerson"); }
        }

        public bool IsValidNewPerson
        {
            get
            {
                return !string.IsNullOrEmpty(NewPerson.Name) && !string.IsNullOrEmpty(NewPerson.Wohnort);
            }
        }

        public MainViewModel()
        {
            LoadData();
        }

        public void AddNewPerson()
        {
            if (IsValidNewPerson)
                Firma.Mitarbeiter.Insert(0, NewPerson);

            ActivePerson = NewPerson;

            NewPerson = new Person();
        }

        private void LoadData()
        {
            firma = new Firma
            {
                Name = "ICT-Berufsbilung Zentralschweiz", Mitarbeiter = new ObservableCollection<Person>
                {
                    new Person { Name="Roger Erni", Wohnort="Kriens", Alter=45 },
                    new Person { Name="Horst Lang", Wohnort="Geuensee", Alter=48 },
                    new Person { Name="Julia Stadelmann", Wohnort="Luzern", Alter=24 },
                    new Person { Name="Kurt Fischer", Wohnort="Kriens", Alter=65 },
                    new Person { Name="Urs Nussbaumer", Wohnort="Ebikon", Alter=47 }
                }
            };
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}
