﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBinding_Liste_Sample
{
    public class Person
    {
        public string Name { get; set; }
        public string Wohnort { get; set; }
        public int? Alter { get; set; }
    }
}
