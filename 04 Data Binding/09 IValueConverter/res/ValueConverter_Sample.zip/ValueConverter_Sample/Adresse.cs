﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValueConverter_Sample
{
    public class Adresse : INotifyPropertyChanged
    {
        int _anrede;

        public int Anrede
        {
            get { return _anrede; }
            set { _anrede = value; OnPropertyChanged("Anrede"); }
        }


        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; OnPropertyChanged("Name"); }

        }

        string _ort;

        public string Ort
        {
            get { return _ort; }
            set { _ort = value; OnPropertyChanged("Ort"); }

        }

        public Adresse(int anrede, string name, string ort)
        {
            Anrede = anrede;
            Name = name;
            Ort = ort;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
