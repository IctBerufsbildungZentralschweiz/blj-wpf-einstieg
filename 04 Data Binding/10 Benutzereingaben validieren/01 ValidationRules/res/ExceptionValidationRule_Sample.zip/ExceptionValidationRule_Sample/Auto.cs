﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionValidationRule_Sample
{
    public class Auto : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        decimal _preis;

        public decimal Preis
        {
            get { return _preis;}
            set
            {
                if (value < 0)  
                    throw new ArgumentOutOfRangeException("Preis darf nicht negativ sein!");

                _preis = value;
                OnPropertyChanged("Preis");
            }
        }

    }
}
