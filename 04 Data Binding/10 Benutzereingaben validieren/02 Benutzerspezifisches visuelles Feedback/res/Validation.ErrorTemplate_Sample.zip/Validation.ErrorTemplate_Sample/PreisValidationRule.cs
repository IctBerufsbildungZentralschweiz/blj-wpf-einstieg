﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Validation.ErrorTemplate_Sample
{
    public class PreisValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            decimal val;
            if (decimal.TryParse(value.ToString(), out val))
            {
                if (val < 0)
                    return new ValidationResult(false, "Preis darf nicht negativ sein!");
            }
            else
            {
                return new ValidationResult(false, "Preis darf keinen Buchstaben und/oder Sonderzeichen enthalten!");
            }
            return ValidationResult.ValidResult;
        }
    }
}
